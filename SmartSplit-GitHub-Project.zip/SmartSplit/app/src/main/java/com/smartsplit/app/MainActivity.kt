package com.smartsplit.app

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class AppChoice(val label: String, val packageName: String)

class MainActivity : ComponentActivity() {
    private val backgroundColor = Color(0xFF10131B)
    private val panelColor = Color(0xFF1B2130)
    private val accent = Color(0xFF7C8CFF)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val choices = loadLaunchableApps()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = accent,
                    background = backgroundColor,
                    surface = panelColor
                )
            ) {
                SmartSplitScreen(
                    apps = choices,
                    onLaunchPair = { first, second -> launchPair(first, second) },
                    onOpenFontSettings = { openFontSettings() }
                )
            }
        }
    }

    @Suppress("QueryPermissionsNeeded")
    private fun loadLaunchableApps(): List<AppChoice> {
        val pm = packageManager
        return pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .filter { it.packageName != packageName }
            .map {
                AppChoice(pm.getApplicationLabel(it).toString(), it.packageName)
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun launchPair(first: AppChoice?, second: AppChoice?) {
        if (first == null || second == null) {
            Toast.makeText(this, "Choose two different apps first.", Toast.LENGTH_SHORT).show()
            return
        }
        if (first.packageName == second.packageName) {
            Toast.makeText(this, "Choose two different apps.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val firstIntent = packageManager.getLaunchIntentForPackage(first.packageName)
                ?: throw IllegalStateException("First app cannot be opened")
            firstIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
            startActivity(firstIntent)
            val secondIntent = packageManager.getLaunchIntentForPackage(second.packageName)
                ?: throw IllegalStateException("Second app cannot be opened")
            secondIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
            startActivity(secondIntent)
            Toast.makeText(
                this,
                "Apps requested. If they open full-screen, use Recents and choose Split screen.",
                Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not launch both apps: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun openFontSettings() {
        try {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }
}

@Composable
private fun SmartSplitScreen(
    apps: List<AppChoice>,
    onLaunchPair: (AppChoice?, AppChoice?) -> Unit,
    onOpenFontSettings: () -> Unit
) {
    var first by remember { mutableStateOf<AppChoice?>(null) }
    var second by remember { mutableStateOf<AppChoice?>(null) }
    var activeSlot by remember { mutableIntStateOf(1) }
    var search by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) }

    val filtered = apps.filter { it.label.contains(search, ignoreCase = true) }
    val dark = Color(0xFF10131B)
    val panel = Color(0xFF1B2130)
    val accent = Color(0xFF8795FF)
    val muted = Color(0xFFADB5C8)

    Column(
        Modifier.fillMaxSize().background(dark).padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("SmartSplit", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Multitask with more freedom", color = muted, fontSize = 13.sp)
            }
            Text("1.0", color = accent, fontSize = 12.sp)
        }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppSlot("APP 1", first?.label ?: "Choose an app", activeSlot == 1, panel, accent) {
                activeSlot = 1
                selectedTab = 0
            }
            AppSlot("APP 2", second?.label ?: "Choose an app", activeSlot == 2, panel, accent) {
                activeSlot = 2
                selectedTab = 0
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = { onLaunchPair(first, second) },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text("Launch split-screen pair", fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Android and HiOS decide whether an app can enter split-screen. If automatic pairing is blocked, open Recent apps and select Split screen.",
            color = muted, fontSize = 11.sp
        )
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = selectedTab == 0, onClick = { selectedTab = 0 }, label = { Text("Apps") })
            FilterChip(selected = selectedTab == 1, onClick = { selectedTab = 1 }, label = { Text("Fonts") })
        }
        if (selectedTab == 0) {
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = search, onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search installed apps") },
                singleLine = true
            )
            Text(
                if (activeSlot == 1) "Select an app for APP 1" else "Select an app for APP 2",
                color = Color.White, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(vertical = 10.dp)
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(filtered, key = { it.packageName }) { app ->
                    Row(
                        Modifier.fillMaxWidth()
                            .background(panel, RoundedCornerShape(12.dp))
                            .clickable {
                                if (activeSlot == 1) first = app else second = app
                                activeSlot = if (activeSlot == 1) 2 else 1
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(app.label, color = Color.White, modifier = Modifier.weight(1f))
                        val isSelected = app == first || app == second
                        Text(if (isSelected) "Selected" else "Choose", color = accent, fontSize = 12.sp)
                    }
                }
            }
        } else {
            Spacer(Modifier.height(12.dp))
            Text("Font previews", color = Color.White, fontWeight = FontWeight.SemiBold)
            Text("These previews change text inside SmartSplit only. System-wide fonts must be changed in HiOS settings.", color = muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            FontPreview("Sans", FontFamily.SansSerif, panel)
            FontPreview("Serif", FontFamily.Serif, panel)
            FontPreview("Monospace", FontFamily.Monospace, panel)
            FontPreview("Cursive", FontFamily.Cursive, panel)
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onOpenFontSettings, modifier = Modifier.fillMaxWidth()) {
                Text("Open phone display / font settings")
            }
        }
    }
}

@Composable
private fun AppSlot(
    title: String, appName: String, selected: Boolean,
    panel: Color, accent: Color, onClick: () -> Unit
) {
    Column(
        Modifier.weight(1f).background(panel, RoundedCornerShape(15.dp))
            .clickable(onClick = onClick).padding(13.dp)
    ) {
        Text(title, color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(appName, color = Color.White, fontSize = 14.sp, maxLines = 1)
        Text(if (selected) "Selecting…" else "Tap to select", color = Color(0xFFADB5C8), fontSize = 10.sp)
    }
}

@Composable
private fun FontPreview(name: String, family: FontFamily, panel: Color) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 8.dp)
            .background(panel, RoundedCornerShape(12.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(name, color = Color(0xFFADB5C8), modifier = Modifier.width(100.dp), fontSize = 12.sp)
        Text("SmartSplit — Multitasking", color = Color.White, fontFamily = family, fontSize = 16.sp)
    }
}
