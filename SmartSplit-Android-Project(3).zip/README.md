# SmartSplit

An Android starter app for selecting two installed apps, attempting adjacent launches, and previewing font families.

## Build the APK
Push this project to the `main` branch of your GitHub repository, or open **Actions → Build SmartSplit APK → Run workflow**. When the workflow completes, open its run, scroll to **Artifacts**, and download `SmartSplit-debug-apk`.

## Important Android / HiOS limitations
- Android and the phone manufacturer control split-screen. `FLAG_ACTIVITY_LAUNCH_ADJACENT` is a request, not a guarantee. Some apps or firmware builds will ignore it.
- A normal third-party app cannot change the system-wide font without supported manufacturer settings or privileged access. The font samples in this app are previews, and the button opens Android display settings.
- The app lists installed launchable apps. Package visibility and firmware behavior may vary.

## Project
- Package: `com.smartsplit.app`
- Minimum Android: API 26
- Target SDK: 35
