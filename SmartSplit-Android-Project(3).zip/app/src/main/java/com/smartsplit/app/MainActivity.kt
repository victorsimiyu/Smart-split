package com.smartsplit.app

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private data class AppChoice(val label: String, val packageName: String)
    private val choices = mutableListOf<AppChoice>()
    private lateinit var first: Spinner
    private lateinit var second: Spinner
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        loadApps()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(Color.rgb(12, 18, 34))
        }
        val title = TextView(this).apply {
            text = "SmartSplit"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(title)
        page.addView(TextView(this).apply {
            text = "Choose two apps and try opening them side by side."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(6), 0, dp(20))
        })
        first = Spinner(this)
        second = Spinner(this)
        addLabel(page, "TOP / FIRST APP")
        page.addView(first, matchWrap())
        addLabel(page, "BOTTOM / SECOND APP")
        page.addView(second, matchWrap())

        val launch = Button(this).apply {
            text = "OPEN IN SPLIT SCREEN"
            setOnClickListener { openSelectedApps() }
        }
        page.addView(launch, matchWrap(dp(18)))

        status = TextView(this).apply {
            text = "Loading apps…"
            textSize = 13f
            setTextColor(Color.rgb(170, 205, 255))
            setPadding(0, dp(12), 0, dp(18))
        }
        page.addView(status)

        addLabel(page, "FONT STYLE PREVIEW")
        val fontNames = listOf("Default", "Serif", "Monospace", "Sans Serif", "Casual")
        val fonts = listOf(
            Typeface.DEFAULT, Typeface.SERIF, Typeface.MONOSPACE,
            Typeface.SANS_SERIF, Typeface.create("casual", Typeface.NORMAL)
        )
        fontNames.forEachIndexed { i, name ->
            page.addView(TextView(this).apply {
                text = "$name — SmartSplit sample text"
                textSize = 17f
                typeface = fonts[i]
                setTextColor(Color.WHITE)
                setPadding(dp(10), dp(7), dp(10), dp(7))
            })
        }

        val settings = Button(this).apply {
            text = "PHONE DISPLAY / FONT SETTINGS"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
        }
        page.addView(settings, matchWrap(dp(14)))
        page.addView(TextView(this).apply {
            text = "Note: Split-screen availability and system font changes are controlled by Android/HiOS. Some apps may not support multi-window."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(12), 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun addLabel(parent: LinearLayout, value: String) {
        parent.addView(TextView(this).apply {
            text = value
            textSize = 12f
            setTextColor(Color.rgb(130, 180, 255))
            setPadding(0, dp(12), 0, dp(5))
        })
    }

    private fun matchWrap(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    @Suppress("DEPRECATION")
    private fun loadApps() {
        val pm = packageManager
        val list = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { AppChoice(pm.getApplicationLabel(it).toString(), it.packageName) }
            .sortedBy { it.label.lowercase() }
        choices.clear()
        choices.addAll(list)
        val labels = list.map { it.label }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        first.adapter = adapter
        second.adapter = adapter
        if (list.size > 1) second.setSelection(1)
        status.text = "${list.size} launchable apps found on this phone."
    }

    private fun openSelectedApps() {
        if (choices.isEmpty()) {
            status.text = "No launchable apps were found."
            return
        }
        val a = choices.getOrNull(first.selectedItemPosition) ?: return
        val b = choices.getOrNull(second.selectedItemPosition) ?: return
        if (a.packageName == b.packageName) {
            status.text = "Choose two different apps."
            return
        }
        try {
            val firstIntent = packageManager.getLaunchIntentForPackage(a.packageName) ?: return
            firstIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
            startActivity(firstIntent)
            status.text = "Opened ${a.label}. Now opening ${b.label}; HiOS decides whether split-screen is available."
            val secondIntent = packageManager.getLaunchIntentForPackage(b.packageName) ?: return
            secondIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
            startActivity(secondIntent)
        } catch (e: Exception) {
            status.text = "HiOS did not allow automatic split-screen. Open Recent Apps and choose Split screen if the option appears."
        }
    }
}
